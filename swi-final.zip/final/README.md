### Guide
#### Compile
```shell
gcc q1.c -o q1
./q1
```